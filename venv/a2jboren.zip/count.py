count = arcpy.GetCount_management("zipcodes")
print count

